import streamlit as st
from pypdf import PdfReader
from io import BytesIO
from collections import Counter
import re

st.set_page_config(
    page_title="Smart Study Planner",
    page_icon="📚",
    layout="wide"
)

st.title("📚 Smart Study Planner")
st.write("Upload multiple subject notes and get your study priorities!")

# -------------------------------
# STOP WORDS
# -------------------------------

stop_words = {
    "the", "is", "are", "was", "were", "and", "or",
    "of", "in", "to", "for", "a", "an", "with",
    "on", "by", "as", "at", "from", "this", "that",
    "it", "be", "can", "will", "which", "what",
    "how", "when", "where", "their", "these",
    "those", "has", "have", "had", "been", "being",
    "into", "also", "such", "than", "then", "there",
    "they", "them", "its", "not", "but", "if",
    "we", "you", "your", "our", "each", "all",
    "any", "more", "most", "some", "other",
    "used", "use", "using", "based", "example"
}

# -------------------------------
# READ PDF OR TXT
# -------------------------------

def read_file(file):

    if file.name.lower().endswith(".pdf"):

        pdf = PdfReader(
            BytesIO(file.getvalue())
        )

        text = ""

        for page in pdf.pages:
            text += (page.extract_text() or "") + "\n"

        return text

    else:

        return file.getvalue().decode(
            "utf-8",
            errors="ignore"
        )

# -------------------------------
# FIND TOPICS
# -------------------------------

def find_topics(text):

    lines = text.splitlines()
    topics = []

    for line in lines:

        line = line.strip()

        if not line or len(line) > 100:
            continue

        words = line.split()

        if len(words) < 2 or len(words) > 12:
            continue

        numbered = re.match(
            r"^(\d+(\.\d+)*[\).:]?\s+|unit\s+\w+|chapter\s+\w+|module\s+\w+)",
            line,
            re.IGNORECASE
        )

        letters = [c for c in line if c.isalpha()]

        uppercase = (
            len(letters) > 0 and
            sum(c.isupper() for c in letters)
            / len(letters) > 0.65
        )

        if numbered or uppercase:
            clean = re.sub(
                r"^(\d+(\.\d+)*[\).:]?\s+)",
                "",
                line
            )

            clean = re.sub(
                r"^(unit|chapter|module)\s+\w+[\s:.-]*",
                "",
                clean,
                flags=re.IGNORECASE
            )

            clean = clean.strip(" :-.")

            if len(clean.split()) >= 2:
                topics.append(clean)

    return topics

# -------------------------------
# ANALYSE IMPORTANCE
# -------------------------------

def analyse_notes(text):

    headings = find_topics(text)

    results = []

    if headings:

        topic_counts = Counter(
            heading.lower() for heading in headings
        )

        for topic, heading_count in topic_counts.items():

            display_name = next(
                h for h in headings if h.lower() == topic
            )

            mentions = len(
                re.findall(
                    re.escape(topic),
                    text,
                    re.IGNORECASE
                )
            )

            score = heading_count * 3 + mentions

            results.append({
                "topic": display_name,
                "score": score
            })

        results.sort(
            key=lambda x: x["score"],
            reverse=True
        )

        return results, "Headings and repeated mentions"

    # Fallback when no headings are found
    words = re.findall(
        r"\b[a-zA-Z]{4,}\b",
        text.lower()
    )

    useful_words = [
        word for word in words
        if word not in stop_words
    ]

    pairs = [
        useful_words[i] + " " + useful_words[i + 1]
        for i in range(len(useful_words) - 1)
    ]

    counts = Counter(pairs)

    for topic, count in counts.most_common(10):

        results.append({
            "topic": topic.title(),
            "score": count
        })

    return results, "Repeated keywords (no headings found)"

# -------------------------------
# STUDENT DETAILS
# -------------------------------

st.subheader("👩‍🎓 Student Details")

name = st.text_input("Enter your name")

days = st.number_input(
    "How many days are left for your exams?",
    min_value=1,
    max_value=180,
    value=7
)

hours = st.number_input(
    "How many hours can you study per day?",
    min_value=1,
    max_value=12,
    value=2
)

# -------------------------------
# MULTIPLE FILE UPLOAD
# -------------------------------
# Multiple Subject File Upload

st.subheader("📂 Upload Your Subject Notes")

uploaded_files = st.file_uploader(
    "Upload multiple PDF or TXT files",
    type=["pdf", "txt"],
    accept_multiple_files=True
)

if uploaded_files:

    st.success(
        f"{len(uploaded_files)} files uploaded successfully!"
    )

    for file in uploaded_files:

        st.write("📄", file.name)

   
if uploaded_files:

    st.success(
        f"{len(uploaded_files)} subject file(s) uploaded!"
    )

    all_subjects = []

    # Analyse each uploaded file
    for file in uploaded_files:

        subject_name = file.name.rsplit(".", 1)[0]

        with st.spinner(
            f"Analysing {subject_name}..."
        ):

            try:

                text = read_file(file)

                if not text.strip():

                    st.warning(
                        f"No readable text found in {subject_name}."
                    )
                    continue

                topics, method = analyse_notes(text)

                all_subjects.append({
                    "subject": subject_name,
                    "topics": topics,
                    "method": method,
                    "text": text
                })

            except Exception as e:

                st.error(
                    f"Error reading {file.name}: {e}"
                )

    # -------------------------------
    # DISPLAY ANALYSIS
    # -------------------------------

    if all_subjects:

        st.divider()

        st.header("🎯 Your Subject Analysis")

        for subject in all_subjects:

            with st.expander(
                "📘 " + subject["subject"],
                expanded=True
            ):

                st.write(
                    "Analysis method:",
                    subject["method"]
                )

                topics = subject["topics"]

                if not topics:

                    st.warning(
                        "No topics could be identified."
                    )
                    continue

                st.subheader("⭐ Important Topics")

                for index, item in enumerate(topics):

                    if index < 3:
                        priority = "HIGH"
                        emoji = "🔴"

                    elif index < 6:
                        priority = "MEDIUM"
                        emoji = "🟡"

                    else:
                        priority = "LOW"
                        emoji = "🟢"

                    st.markdown(
                        f"{emoji} **{item['topic']}** "
                        f"- {priority}"
                    )

                    st.caption(
                        f"Repetition score: {item['score']}"
                    )

                st.divider()

                st.subheader("📖 Recommended Learning Order")

                for index, item in enumerate(topics, 1):

                    st.write(
                        f"{index}. {item['topic']}"
                    )

                st.text_area(
                    "Notes Preview",
                    subject["text"][:1500],
                    height=120,
                    key="preview_" + subject["subject"]
                )

        # -------------------------------
        # STUDY PLAN
        # -------------------------------

        st.divider()

        st.header("📅 Your Study Plan")

        if st.button("Generate My Study Plan"):

            if not name.strip():

                st.warning("Please enter your name.")

            else:

                st.success(
                    f"Study plan generated for {name}!"
                )

                st.write(
                    f"Available days: {days}"
                )

                st.write(
                    f"Daily study hours: {hours}"
                )

                total_topics = sum(
                    len(s["topics"])
                    for s in all_subjects
                )

                if total_topics == 0:

                    st.warning(
                        "No topics are available for planning."
                    )

                else:

                    # Create a combined priority list
                    combined = []

                    for subject in all_subjects:

                        for index, topic in enumerate(
                            subject["topics"]
                        ):

                            combined.append({
                                "subject": subject["subject"],
                                "topic": topic["topic"],
                                "priority": index
                            })

                    # High priority topics first
                    combined.sort(
                        key=lambda x: x["priority"]
                    )

                    topics_per_day = max(
                        1,
                        (total_topics + int(days) - 1)
                        // int(days)
                    )

                    for day in range(int(days)):

                        start = day * topics_per_day
                        end = min(
                            start + topics_per_day,
                            total_topics
                        )

                        if start >= total_topics:
                            break

                        st.subheader(
                            f"📅 Day {day + 1}"
                        )

                        for item in combined[start:end]:

                            st.write(
                                f"📘 {item['subject']} "
                                f"- {item['topic']}"
                            )

                        st.caption(
                            f"Suggested study time: {hours} hours"
                        )

                        st.divider()

                    st.success(
                        "Your personalized study plan is ready!"
                    )

else:

    st.info(
        "Upload multiple subject files to start your analysis."
    )